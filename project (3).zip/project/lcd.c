#include "lcd.h"
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <math.h> // for abs and max
#include <string.h>
#include <stdint.h> // for fixed-width integers
#include <arpa/inet.h> // for ntohs and ntohl
#include "config.h"

static void drawPixel(int x, int y, unsigned char *color_buf, int w, int h, int depth, int x0, int y0);

int fb_size = 800 * 480 * 4;    //帧缓冲设备文件的大小
int fd_lcd; //帧缓冲设备文件的文件描述符
unsigned int *pmap; //映射区首地址

/************************************************
 * 功能：初始化LCD屏幕
 * 参数：无
 * 返回值：
 *      -1：失败
 *       0：成功
*************************************************/
int lcdInit()
{
    // 打开帧缓冲设备文件(/dev/fb0)
    fd_lcd = open("/dev/fb0", O_RDWR);
    if (-1 == fd_lcd)
    {
        perror("open lcd error");
        return -1;
    }
    // 映射
    pmap = mmap(NULL, fb_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd_lcd, 0);
    if (MAP_FAILED == pmap)
    {
        perror("mmap error");
        close(fd_lcd);
        return -1;
    }
    return 0;
}

/************************************************
 * 功能：关闭LCD屏幕
 * 参数：无
 * 返回值：无
*************************************************/
void lcdClose()
{
    // 解除映射
    munmap(pmap, fb_size);
    // 关闭帧缓冲设备文件
    close(fd_lcd);
}

/************************************************
 * 功能：刷背景色
 * 参数：
 *      color：要显示的背景颜色
 * 返回值：无
*************************************************/
void lcdBrushBG(unsigned int color)
{
    for (int y = 0; y < 480; y++)
    {
        for (int x = 0; x < 800; x++)
        {
            *(pmap + y * 800 + x) = color;
        }
    }
}

/************************************************
 * 功能：在指定的位置画像素点
 * 参数：
 *      x,y：像素点的坐标
 *      color：像素点的颜色值
 * 返回值：无
*************************************************/
void lcdDrawPoint(int x, int y, unsigned int color)
{
    if (x >= 0 && x < 800 && y >= 0 && y < 480)
    {
        *(pmap + y * 800 + x) = color;
    }
}

/************************************************
 * 功能：在指定的位置画矩形(实心)
 * 参数：
 *      x0,y0：矩形显示的位置(左上顶点)
 *      w,h：矩形的宽度和高度
 *      color：矩形的填充颜色
 * 返回值：无
*************************************************/
void lcdDrawRect(int x0, int y0, int w, int h, unsigned int color)
{
    for (int y = y0; y < y0 + h; y++)
    {
        for (int x = x0; x < x0 + w; x++)
        {
            lcdDrawPoint(x, y, color);
        }
    }
}

/************************************************
 * 功能：在指定的位置画圆形(实心)
 * 参数：
 *      x0,y0：圆心的坐标
 *      r：半径
 *      color：圆形的填充颜色
 * 返回值：无
*************************************************/
void lcdDrawCircle(int x0, int y0, int r, unsigned int color)
{
    for (int y = y0 - r; y < y0 + r; y++)
    {
        for (int x = x0 - r; x < x0 + r; x++)
        {
            if ((y - y0) * (y - y0) + (x - x0) * (x - x0) <= r * r)
            {
                // 是圆内的点，显示
                lcdDrawPoint(x, y, color);
            }
        }
    }
}

/************************************************
 * 功能：在指定的位置显示图片
 * 参数：
 *      x0,y0：图片显示的位置(左上顶点的坐标)
 *      pic_path：要显示的图片的路径名
 * 返回值：无
*************************************************/

void lcdDrawBMP(int x0, int y0, const char *pic_path)
{
    // 打开图片文件
    int fd_pic = open(pic_path, O_RDONLY);
    if (-1 == fd_pic)
    {
        perror("open pic error");
        return;
    }
    // 读取图片重要数据(魔数、像素数组的文件偏移量、宽度、高度、色深)
    short MS, depth; // 魔数、色深
    int offset, w, h; // 像素数组文件偏移量、宽度、高度
    read(fd_pic, &MS, 2);
    if (0x4D42 != MS)
    {
        printf("this pic is not bmp!\n");
        close(fd_pic);
        return;
    }
    lseek(fd_pic, 0x0A, SEEK_SET);
    read(fd_pic, &offset, 4);
    lseek(fd_pic, 0x12, SEEK_SET);
    read(fd_pic, &w, 4);
    read(fd_pic, &h, 4);
    lseek(fd_pic, 0x1C, SEEK_SET);
    read(fd_pic, &depth, 2);

    int full_bytes = (4 - (w * depth / 8) % 4) % 4;   // 每一行的填充字节数 = (4-一行像素点颜色值总字节数%4)%4
    int buf_size = (w * depth / 8 + full_bytes) * abs(h);    // 像素数组大小 = (一行像素点颜色值的总字节数+填充字节数)*行数
    unsigned char color_buf[buf_size];  // 像素数组数据
    lseek(fd_pic, offset, SEEK_SET);
    read(fd_pic, color_buf, buf_size);
    // 遍历整个图片，将每个像素点的颜色值取出来，按照argb的顺序重新排列
    unsigned char *p = color_buf;
    unsigned char a, r, g, b;
    for (int y = 0; y < abs(h); y++)
    {
        for (int x = 0; x < w; x++)
        {
            // 获取一个像素点的4个颜色分量
            b = *p++;
            g = *p++;
            r = *p++;
            if (depth == 24)
            {
                // 是24位的bmp图片，没有透明度，需要手动赋值
                a = 0;
            }
            else if (depth == 32)
            {
                // 是32位的bmp图片，有透明度，直接获取
                a = *p++;
            }
            // 将获取到颜色分量按照argb的顺序重新排列
            unsigned int color = a << 24 | r << 16 | g << 8 | b;
            // 将像素点显示到屏幕上去
            if (h > 0)
            {
                // 从下往上显示
                lcdDrawPoint(x + x0, h - 1 - y + y0, color);
            }
            else
            {
                // 从上往下显示
                lcdDrawPoint(x + x0, y + y0, color);
            }
        }
        // 每显示完一行像素点，就需要跳过后面的填充字节
        p += full_bytes;
    }
    // 关闭图片文件
    close(fd_pic);
}
unsigned char* loadBMP(const char *pic_path, int *w, int *h, int *depth) {
    int fd_pic = open(pic_path, O_RDONLY);
    if (fd_pic == -1) {
        perror("open pic error");
        return NULL;
    }

    // 检查文件是否为 BMP 格式
    short MS;
    if (read(fd_pic, &MS, 2) != 2 || MS != 0x4D42) {
        printf("this pic is not bmp!\n");
        close(fd_pic);
        return NULL;
    }

    // 获取图像数据偏移量
    lseek(fd_pic, 0x0A, SEEK_SET);
    uint32_t offset;
    if (read(fd_pic, &offset, 4) != 4) {
        fprintf(stderr, "Failed to read offset from file\n");
        close(fd_pic);
        return NULL;
    }

    // 获取宽度和高度
    lseek(fd_pic, 0x12, SEEK_SET);
    uint32_t width, height;
    if (read(fd_pic, &width, 4) != 4 || read(fd_pic, &height, 4) != 4) {
        fprintf(stderr, "Failed to read width or height from file\n");
        close(fd_pic);
        return NULL;
    }

    // 获取颜色深度
    lseek(fd_pic, 0x1C, SEEK_SET);
    uint16_t bit_depth;
    if (read(fd_pic, &bit_depth, 2) != 2) {
        fprintf(stderr, "Failed to read bit depth from file\n");
        close(fd_pic);
        return NULL;
    }

    // 打印调试信息
    printf("Loaded BMP: width=%u, height=%d, depth=%u\n", width, height, bit_depth);

    // 验证深度是否合理
    if (bit_depth != 24 && bit_depth != 32) {
        printf("Unsupported bit depth: %u\n", bit_depth);
        close(fd_pic);
        return NULL;
    }

    *w = width;
    *h = height;
    *depth = bit_depth;

    // 计算每行字节数（包括填充）
    int row_stride = ((width * bit_depth / 8 + 3) / 4) * 4; // Align to 4 bytes
    int buf_size = row_stride * abs(height);

    // 分配内存并检查是否成功
    unsigned char *color_buf = malloc(buf_size);
    if (!color_buf) {
        perror("malloc color buffer error");
        close(fd_pic);
        return NULL;
    }

    // 读取图像数据
    lseek(fd_pic, offset, SEEK_SET);
    ssize_t bytesRead = read(fd_pic, color_buf, buf_size);
    if (bytesRead != buf_size) {
        fprintf(stderr, "Failed to read entire file: expected %d bytes, got %zd\n", buf_size, bytesRead);
        free(color_buf);
        close(fd_pic);
        return NULL;
    }

    close(fd_pic); // 确保文件总是被关闭

    return color_buf;
}
void freeColorBuffer(unsigned char *buffer) {
    if (buffer) {
        free(buffer);
    }
}

void lcdDrawBlindsEffect(int x0, int y0, const char *pic_path) {
    int w, h, depth;
    unsigned char *color_buf = loadBMP(pic_path, &w, &h, &depth);
    if (!color_buf) {
        fprintf(stderr, "Failed to load BMP file: %s\n", pic_path);
        return;
    }

    // 百叶窗效果逻辑
    for (int y = 0; y < abs(h); y++) {
        for (int x = 0; x < w; x++) {
            drawPixel(x + x0, abs(h) - 1 - y + y0, color_buf, w, h, depth, x0, y0);
        }
        usleep(5000); // 5ms延迟
    }

    free(color_buf);
}
void lcdDrawCircleExpandEffect(int x0, int y0, const char *pic_path) {
    int w, h, depth;
    unsigned char *color_buf = loadBMP(pic_path, &w, &h, &depth);
    if (!color_buf) {
        fprintf(stderr, "Failed to load BMP file: %s\n", pic_path);
        return;
    }

    // 圆形扩散效果逻辑
    int cx = w / 2;
    int cy = abs(h) / 2;
    for (int r = 1; r <= max(w, abs(h)) / 2; r++) {
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                if (dx * dx + dy * dy <= r * r) {
                    int x = cx + dx;
                    int y = cy + dy;
                    if (x >= 0 && x < w && abs(y) >= 0 && abs(y) < abs(h))
                        drawPixel(x + x0, abs(y) + y0, color_buf, w, h, depth, x0, y0);
                }
            }
        }
        usleep(5000); // 5ms延迟
    }

    free(color_buf);
}
void lcdDrawRectExpandEffect(int x0, int y0, const char *pic_path) {
    int w, h, depth;
    unsigned char *color_buf = loadBMP(pic_path, &w, &h, &depth);
    if (!color_buf) {
        fprintf(stderr, "Failed to load BMP file: %s\n", pic_path);
        return;
    }

    // 矩形扩散效果逻辑
    int cx = w / 2;
    int cy = abs(h) / 2;
    for (int size = 1; size <= max(w, abs(h)) / 2; size++) {
        for (int dy = -size; dy <= size; dy++) {
            int x = cx + size;
            int y = cy + dy;
            if (x >= 0 && x < w && abs(y) >= 0 && abs(y) < abs(h))
                drawPixel(x + x0, abs(y) + y0, color_buf, w, h, depth, x0, y0);

            x = cx - size;
            if (x >= 0 && x < w && abs(y) >= 0 && abs(y) < abs(h))
                drawPixel(x + x0, abs(y) + y0, color_buf, w, h, depth, x0, y0);
        }

        for (int dx = -size + 1; dx < size; dx++) {
            int x = cx + dx;
            int y = cy + size;
            if (x >= 0 && x < w && abs(y) >= 0 && abs(y) < abs(h))
                drawPixel(x + x0, abs(y) + y0, color_buf, w, h, depth, x0, y0);

            y = cy - size;
            if (x >= 0 && x < w && abs(y) >= 0 && abs(y) < abs(h))
                drawPixel(x + x0, abs(y) + y0, color_buf, w, h, depth, x0, y0);
        }
        usleep(5000); // 5ms延迟
    }

    free(color_buf);
}
void lcdDrawCurtainEffect(int x0, int y0, const char *pic_path) {
    int w, h, depth;
    unsigned char *color_buf = loadBMP(pic_path, &w, &h, &depth);
    if (!color_buf) {
        fprintf(stderr, "Failed to load BMP file: %s\n", pic_path);
        return;
    }

    // 幕布效果逻辑
    for (int x = 0; x < w; x++) {
        for (int y = 0; y < abs(h); y++) {
            drawPixel(x + x0, y + y0, color_buf, w, h, depth, x0, y0);
        }
        usleep(5000); // 5ms延迟
    }

    free(color_buf);
}
void lcdDrawSlowEnterEffect(int x0, int y0, const char *pic_path) {
    int w, h, depth;
    unsigned char *color_buf = loadBMP(pic_path, &w, &h, &depth);
    if (!color_buf) {
        fprintf(stderr, "Failed to load BMP file: %s\n", pic_path);
        return;
    }

    // 缓慢进入效果逻辑
    for (int y = 0; y < abs(h); y++) {
        for (int x = 0; x < w; x++) {
            drawPixel(x + x0, y + y0, color_buf, w, h, depth, x0, y0);
        }
        usleep(5000); // 5ms延迟
    }

    free(color_buf);
}
// 辅助函数用于绘制单个像素
static void drawPixel(int x, int y, unsigned char *color_buf, int w, int h, int depth, int x0, int y0)
{
    int row_stride = (w * depth / 8 + (4 - (w * depth / 8) % 4) % 4);
    unsigned char *p = color_buf + (abs(y) * row_stride + x * depth / 8);

    unsigned char b = p[0];
    unsigned char g = p[1];
    unsigned char r = p[2];
    unsigned char a = (depth == 32) ? p[3] : 0xFF;

    unsigned int color = a << 24 | r << 16 | g << 8 | b;
    if (h > 0) {
        lcdDrawPoint(x + x0, abs(h) - 1 - abs(y) + y0, color); // 注意这里的坐标转换
    } else {
        lcdDrawPoint(x + x0, abs(y) + y0, color);
    }
}

static inline int max(int a, int b) {
    return (a > b) ? a : b;
}


