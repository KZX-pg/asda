#include "lcd.h"
#include "touch.h"
#include "music.h"
#include "songtu.h"
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <linux/input.h> 
#include <fcntl.h>
#include "config.h"

int fd_touch;   // 触摸屏设备文件描述符
pthread_mutex_t isLockedMutex = PTHREAD_MUTEX_INITIALIZER;
volatile int isLocked; // 初始化为锁定状态
static pthread_t touchThread;
static const int password[PASSWORD_LENGTH] = {1, 1, 1, 1, 1, 1}; // 正确的密码序列
int currentIndex = 0;
volatile int passwordStep = 0;
int currentEffectIndex = 0;
const char *effectNames[] = {"Blinds", "Circle Expand", "Rect Expand", "Curtain", "Slow Enter"};
void (*effectFunctions[]) (int, int, const char*) = {
    lcdDrawBlindsEffect,
    lcdDrawCircleExpandEffect,
    lcdDrawRectExpandEffect,
    lcdDrawCurtainEffect,
    lcdDrawSlowEnterEffect
};

typedef enum {
    MODE_LOCKSCREEN,
    MODE_SELECTION,
    MODE_ALBUM,
    MODE_MUSIC_PLAYER
} AppMode;

static AppMode currentMode = MODE_LOCKSCREEN;

const char *bootImages[NUM_BOOT_IMAGES] = {"./IU002.bmp", "./IU003.bmp", "./IU004.bmp",
                                           "./IU005.bmp", "./IU006.bmp", "./IU007.bmp", "./IU008.bmp", "./IU009.bmp", "./IU010.bmp", "./IU011.bmp", "./IU012.bmp",
                                           "./IU013.bmp", "./IU014.bmp", "./IU015.bmp", "./IU016.bmp", "./IU017.bmp", "./IU018.bmp", "./IU019.bmp", "./IU020.bmp", 
                                           "./IU021.bmp", "./IU022.bmp", "./IU023.bmp", "./IU024.bmp"};

const char *albumImages[NUM_ALBUM_IMAGES] = {"./PG001.bmp", "./PG002.bmp", "./PG003.bmp", "./PG004.bmp", "./PG005.bmp"};

const char *lockScreenImages[NUM_LOCKSCREEN_IMAGES] = {"./lock 001.bmp","./lock 002.bmp","./lock 003.bmp",
                                                       "./lock 004.bmp","./lock 005.bmp","./lock 006.bmp"};

extern void showImage(const char *path);
extern void handleLockScreenTouch(TouchEvent event);
extern void handleUnlockedTouch(TouchEvent event);

void showImage(const char *path) {
    lcdDrawBMP(0, 0, path);
}

void showSelectionScreen() {
    printf("Displaying selection screen...\n");
    showImage("./app.bmp"); // 确保这个文件路径是正确的
}

void switchToNextEffect() {
    currentEffectIndex = (currentEffectIndex + 1) % (sizeof(effectFunctions) / sizeof(effectFunctions[0]));
    printf("Switching to %s Effect\n", effectNames[currentEffectIndex]);
}

void switchToPreviousEffect() {
    currentEffectIndex = (currentEffectIndex - 1 + (sizeof(effectFunctions) / sizeof(effectFunctions[0]))) % (sizeof(effectFunctions) / sizeof(effectFunctions[0]));
    printf("Switching to %s Effect\n", effectNames[currentEffectIndex]);
}

void applyEffectToNewImage(int newIndex) {
    effectFunctions[currentEffectIndex](0, 0, albumImages[newIndex]);
}

void showNextLockScreenImage() {
    if (isLocked) {
        passwordStep = (passwordStep + 1) % NUM_LOCKSCREEN_IMAGES;
        showImage(lockScreenImages[passwordStep]);
    }
}

void showPreviousLockScreenImage() {
    if (isLocked) {
        passwordStep = (passwordStep - 1 + NUM_LOCKSCREEN_IMAGES) % NUM_LOCKSCREEN_IMAGES;
        showImage(lockScreenImages[passwordStep]);
    }
}

void showNextImage() {
    if (!isLocked) {
        currentIndex = (currentIndex + 1) % NUM_ALBUM_IMAGES;
        applyEffectToNewImage(currentIndex);
    }
}

void showPreviousImage() {
    if (!isLocked) {
        currentIndex = (currentIndex - 1 + NUM_ALBUM_IMAGES) % NUM_ALBUM_IMAGES;
        applyEffectToNewImage(currentIndex);
    }
}

void handleUnlockedTouch(TouchEvent event) {
    printf("Handling unlocked touch: type=%d, x=%d, y=%d\n", event.type, event.x, event.y);

    switch (currentMode) {
        case MODE_SELECTION:
            if (event.type == TOUCH_CLICK) {
                if (event.x < SCREEN_WIDTH / 2) { // 点击左半边屏幕（进入相册）
                    currentMode = MODE_ALBUM;
                    currentIndex = 0;
                    showImage(albumImages[currentIndex]);
                } else if (event.x >= SCREEN_WIDTH / 2) { // 点击右半边屏幕（进入音乐播放器）
                    currentMode = MODE_MUSIC_PLAYER;
                    playCurrentSong();
                    showCurrentImage();
                }
            }
            break;

        case MODE_ALBUM:
            if (event.type == TOUCH_SWIPE_LEFT) {
                showPreviousImage();
            } else if (event.type == TOUCH_SWIPE_RIGHT) {
                showNextImage();
            } else if (event.type == TOUCH_SWIPE_UP) {
                switchToNextEffect(); // 切换到下一个特效
            } else if (event.type == TOUCH_SWIPE_DOWN) {
                switchToPreviousEffect(); // 切换到上一个特效
            }
            break;

        case MODE_MUSIC_PLAYER:
            processMusicControlEvents(event);
            break;

        default:
            printf("Unexpected mode in handleUnlockedTouch.\n");
            break;
    }
}

void handleLockScreenTouch(TouchEvent event) {
    static int passwordIndex = 0;
    static bool isProcessing = false;

    if (isProcessing || !isLocked) return;

    isProcessing = true;
    printf("Handling lock screen touch: type=%d, x=%d, y=%d, gestureCode=%d\n", 
           event.type, event.x, event.y, event.gestureCode);

    if (event.type == TOUCH_CLICK && event.gestureCode != -1) {
        int inputDigit = event.x;

        if (inputDigit == -1) { // 取消键
            printf("Cancel button pressed, resetting...\n");
            passwordIndex = 0;
            showImage(lockScreenImages[0]);
        } else if (inputDigit == '*') { // 确认键
            pthread_mutex_lock(&isLockedMutex);
            isLocked = false;
            currentMode = MODE_SELECTION;
            pthread_mutex_unlock(&isLockedMutex);

            printf("Password entered successfully!\n");
            showSelectionScreen();
            passwordIndex = 0;
        } else {
            if (inputDigit >= 0 && inputDigit <= 9) {
                printf("Detected digit: %d, comparing with password[%d] = %d\n", inputDigit, passwordIndex, password[passwordIndex]);

                if (inputDigit == password[passwordIndex]) {
                    showNextLockScreenImage();
                    passwordIndex++;

                    if (passwordIndex >= PASSWORD_LENGTH) {
                        pthread_mutex_lock(&isLockedMutex);
                        isLocked = false;
                        currentMode = MODE_SELECTION;
                        pthread_mutex_unlock(&isLockedMutex);

                        printf("Password entered successfully!\n");
                        showSelectionScreen();
                        passwordIndex = 0;
                    }
                } else {
                    printf("Incorrect input, resetting...\n");
                    passwordIndex = 0;
                }
            } else {
                printf("Invalid input, resetting...\n");
                passwordIndex = 0;
            }
        }
    }
    isProcessing = false;
}

void handleGesture(TouchEvent event) {
    if (isLocked) {
        static int passwordIndex = 0;

        if (event.type == TOUCH_CLICK) {
            printf("Touch event detected at x=%d, y=%d\n", event.x, event.y);

            // 检查是否点击了密码按钮区域
            bool isInButtonArea = (event.x >= BUTTON_X_MIN && event.x <= BUTTON_X_MAX &&
                                   event.y >= BUTTON_Y_MIN && event.y <= BUTTON_Y_MAX);
            printf("Is in button area: %s\n", isInButtonArea ? "Yes" : "No");

            if (isInButtonArea) {
                // 计算按键对应的数字（假设按键按3x4排列）
                int col = (event.x - BUTTON_X_MIN) / BUTTON_WIDTH;
                int row = (event.y - BUTTON_Y_MIN) / BUTTON_HEIGHT;
                int gesture = row * 3 + col;
                printf("Calculated gesture: %d\n", gesture);

                // 确保计算出的gesture在有效范围内
                if (gesture >= 0 && gesture <= 9) { // 数字键
                    printf("Detected gesture: %d, comparing with password[%d] = %d\n", gesture, passwordIndex, password[passwordIndex]);

                    // 成功匹配后再切换图片
                    if (gesture == password[passwordIndex]) {
                        showNextLockScreenImage();
                        passwordIndex++;

                        if (passwordIndex >= PASSWORD_LENGTH) {
                            pthread_mutex_lock(&isLockedMutex);
                            isLocked = 0;
                            pthread_mutex_unlock(&isLockedMutex);

                            printf("Password entered successfully!\n");
                            currentMode = MODE_SELECTION; // 解锁后进入选择界面
                            showSelectionScreen();
                            passwordIndex = 0; // 重置密码索引
                        }
                    } else {
                        printf("Incorrect input, resetting...\n");
                        passwordIndex = 0; // 重置密码索引
                    }
                }
            } else if (event.x > SCREEN_WIDTH / 2) { // 取消键
                printf("Cancel button pressed, resetting...\n");
                passwordIndex = 0; // 重置密码索引
                showImage(lockScreenImages[0]);
            }
        }
    } else {
        switch (currentMode) {
            case MODE_SELECTION:
                // 处理选择界面的点击事件
                if (event.type == TOUCH_CLICK) {
                    if (event.x < SCREEN_WIDTH / 2) { // 点击左半边屏幕（进入相册）
                        currentMode = MODE_ALBUM;
                        currentIndex = 0;
                        showImage(albumImages[currentIndex]);
                    } else if (event.x >= SCREEN_WIDTH / 2) { // 点击右半边屏幕（进入音乐播放器）
                        currentMode = MODE_MUSIC_PLAYER;
                        playCurrentSong();
                        showCurrentImage();
                    }
                }
                break;

            case MODE_ALBUM:
                // 相册模式下的手势处理逻辑
                if (event.type == TOUCH_SWIPE_LEFT) {
                    showPreviousImage();
                } else if (event.type == TOUCH_SWIPE_RIGHT) {
                    showNextImage();
                } else if (event.type == TOUCH_SWIPE_UP) {
                    switchToNextEffect(); // 切换到下一个特效
                } else if (event.type == TOUCH_SWIPE_DOWN) {
                    switchToPreviousEffect(); // 切换到上一个特效
                }
                break;

            case MODE_MUSIC_PLAYER:
                // 音乐播放器模式下的手势处理逻辑
                processMusicControlEvents(event);
                break;

            default:
                break;
        }
    }
}

void playBootAnimation() {
    for (int i = 0; i < NUM_BOOT_IMAGES; ++i) {
        showImage(bootImages[i]);
        usleep(100000); // 每帧之间等待0.1秒
    }
}

void* bootAnimation(void* arg) {
    playBootAnimation();
    pthread_exit(NULL);
}

void* lockScreenMonitor(void* arg) {
    while (1) {
        sleep(5); // 检查是否超过5秒无操作
        if (isLocked) continue;

        TouchEvent gesture = getTouchData(); 
        if (gesture.type != TOUCH_NONE && gesture.type != -1) {
            printf("Detected gesture: %d\n", gesture.type);
            handleGesture(gesture); // 传递整个结构体
        }
    }
    return NULL;
}

void* touchListener(void *arg) {
    while (1) {
        TouchEvent event = getTouchData();

        if (event.type != TOUCH_NONE) {
            if (isLocked) {
                handleLockScreenTouch(event); 
            } else {
                handleGesture(event); 
            }
        }

        usleep(100000); 
    }
    return NULL;
}

void* keyThread(void* arg) {
    int fd_key = open("/dev/input/event1", O_RDONLY); 
    if (fd_key == -1) {
        perror("open key event error");
        return NULL;
    }

    struct input_event ev;
    while (read(fd_key, &ev, sizeof(ev)) == sizeof(ev)) {
        if (ev.type == EV_KEY && ev.value == 1) { // 按键按下事件
            pthread_mutex_lock(&isLockedMutex);
            if (!isLocked) {
                pthread_mutex_unlock(&isLockedMutex);
                continue; // 如果已经解锁，则忽略按键事件
            }
            pthread_mutex_unlock(&isLockedMutex);

            TouchEvent event = {0}; 
            event.type = TOUCH_CLICK;

            switch (ev.code) {
                case KEY_1: event.x = BUTTON_X_MIN + BUTTON_WIDTH / 2; event.y = BUTTON_Y_MIN + BUTTON_HEIGHT / 4; break;
                case KEY_2: event.x = BUTTON_X_MIN + BUTTON_WIDTH * 3 / 2; event.y = BUTTON_Y_MIN + BUTTON_HEIGHT / 4; break;
                case KEY_3: event.x = BUTTON_X_MIN + BUTTON_WIDTH * 5 / 2; event.y = BUTTON_Y_MIN + BUTTON_HEIGHT / 4; break;
                case KEY_4: event.x = BUTTON_X_MIN + BUTTON_WIDTH / 2; event.y = BUTTON_Y_MIN + BUTTON_HEIGHT * 3 / 4; break;
                case KEY_5: event.x = BUTTON_X_MIN + BUTTON_WIDTH * 3 / 2; event.y = BUTTON_Y_MIN + BUTTON_HEIGHT * 3 / 4; break;
                case KEY_6: event.x = BUTTON_X_MIN + BUTTON_WIDTH * 5 / 2; event.y = BUTTON_Y_MIN + BUTTON_HEIGHT * 3 / 4; break;
                case KEY_7: event.x = BUTTON_X_MIN + BUTTON_WIDTH / 2; event.y = BUTTON_Y_MIN + BUTTON_HEIGHT * 5 / 4; break;
                case KEY_8: event.x = BUTTON_X_MIN + BUTTON_WIDTH * 3 / 2; event.y = BUTTON_Y_MIN + BUTTON_HEIGHT * 5 / 4; break;
                case KEY_9: event.x = BUTTON_X_MIN + BUTTON_WIDTH * 5 / 2; event.y = BUTTON_Y_MIN + BUTTON_HEIGHT * 5 / 4; break;
                case KEY_0: event.x = BUTTON_X_MIN + BUTTON_WIDTH * 3 / 2; event.y = BUTTON_Y_MIN + BUTTON_HEIGHT * 7 / 4; break;
                case KEY_BACKSPACE: event.x = BUTTON_X_MIN + BUTTON_WIDTH * 7 / 2; event.y = BUTTON_Y_MIN + BUTTON_HEIGHT / 2; break; // Cancel button
                case KEY_ENTER: event.x = BUTTON_X_MIN + BUTTON_WIDTH * 3 / 2; event.y = BUTTON_Y_MIN + BUTTON_HEIGHT * 9 / 4; break; // Submit input
                default: continue; // 忽略其他按键
            }

            printf("Key event detected: code=%d, mapped to x=%d, y=%d\n", ev.code, event.x, event.y);

            pthread_mutex_lock(&isLockedMutex);
            handleLockScreenTouch(event); // 传递完整的 TouchEvent 结构体
            pthread_mutex_unlock(&isLockedMutex);
        }
    }

    close(fd_key); // 确保关闭文件描述符
    printf("keyThread exiting...\n");

    return NULL;
}

int main() {
    // 初始化LCD和触摸屏
    if (lcdInit() != 0 || touchInit() != 0) {
        perror("Initialization failed");
        lcdClose();
        touchClose();
        return -1;
    }

    pthread_t bootThread, lockThread, keyThreadHandle, touchThread;

    // 创建开机动画线程并等待其结束
    pthread_create(&bootThread, NULL, bootAnimation, NULL);
    pthread_join(bootThread, NULL); // 等待开机动画线程结束
    showImage(lockScreenImages[0]);

    // 创建锁屏监控线程、键盘监听线程和触摸监听线程
    pthread_create(&lockThread, NULL, lockScreenMonitor, NULL);
    pthread_create(&keyThreadHandle, NULL, keyThread, NULL);
    pthread_create(&touchThread, NULL, touchListener, NULL);

    while (1) {
        sleep(1); // 避免空转消耗CPU资源
    }

    pthread_cancel(lockThread);
    pthread_cancel(keyThreadHandle);
    pthread_cancel(touchThread);
    pthread_join(lockThread, NULL);
    pthread_join(keyThreadHandle, NULL);
    pthread_join(touchThread, NULL);

    // 关闭资源
    touchClose();
    lcdClose();

    return 0;
}