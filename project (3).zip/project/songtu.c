#include <stdbool.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "songtu.h"
#include "touch.h"
#include "music.h"
#include "lcd.h"
#include "config.h"

static bool is_playing = false;
volatile int isLocked = 1; // 初始化为锁定状态
pthread_t touchThread;

void setPlaying(bool playing) {
    is_playing = playing;
}

bool isPlaying() {
    return is_playing;
}

void processMusicControlEvents(TouchEvent event) {
    if (!isLocked && event.type == TOUCH_CLICK) { // 确保只在解锁状态下处理
        int x = event.x;
        int y = event.y;

        if (x >= PREVIOUS_BUTTON_X1 && x <= PREVIOUS_BUTTON_X2 &&
            y >= PREVIOUS_BUTTON_Y1 && y <= PREVIOUS_BUTTON_Y2) {
            previousSong();
        } else if (x >= PLAY_BUTTON_X1 && x <= PLAY_BUTTON_X2 &&
                   y >= PLAY_BUTTON_Y1 && y <= PLAY_BUTTON_Y2) {
            if (isPlaying()) {
                pauseSong();
            } else {
                resumeSong();
            }
        } else if (x >= NEXT_BUTTON_X1 && x <= NEXT_BUTTON_X2 &&
                   y >= NEXT_BUTTON_Y1 && y <= NEXT_BUTTON_Y2) {
            nextSong();
        }
    }
}
void initSongTu() {
    // 初始化LCD和触摸屏
    if (lcdInit() != 0 || touchInit() != 0) {
        perror("Initialization failed");
        exit(EXIT_FAILURE);
    }

    // 显示当前歌曲对应的图片并开始播放第一首歌
    showCurrentImage();
    playCurrentSong();
}
