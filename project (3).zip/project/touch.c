#include "touch.h"
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <linux/input.h>
#include <stdlib.h>
#include "config.h"

int fd_touch;   // 触摸屏设备文件描述符

/************************************************
 * 功能：初始化触摸屏
 * 参数：无
 * 返回值：
 *      -1：失败
 *       0：成功
*************************************************/
int touchInit()
{
    // 打开触摸屏设备文件 /dev/input/event0
    fd_touch = open("/dev/input/event0", O_RDONLY);
    if (-1 == fd_touch)
    {
        perror("open touch error");
        return -1;
    }
    return 0;
}

/************************************************
 * 功能：关闭触摸屏
 * 参数：无
 * 返回值：无
*************************************************/
void touchClose()
{
    close(fd_touch);
}

/************************************************
 * 功能：获取触摸屏数据
 * 参数：无
 * 返回值：TouchEvent 结构体
*************************************************/
TouchEvent getTouchData() {
    struct input_event ev;
    ssize_t res;
    static int startX = 0, startY = 0;
    static int endX = 0, endY = 0;
    static int isTouching = 0;
    TouchEvent touchEvent = {TOUCH_NONE, 0, 0};

    while (1) {
        res = read(fd_touch, &ev, sizeof(ev));
        if (-1 == res) {
            perror("read touch data error");
            return touchEvent;
        }

        if (ev.type == EV_ABS) {
            if (ev.code == ABS_X) {
                if (isTouching) {
                    endX = ev.value * (SCREEN_WIDTH - 1) / 1023;
                } else {
                    startX = ev.value * (SCREEN_WIDTH - 1) / 1023;
                }
            } else if (ev.code == ABS_Y) {
                if (isTouching) {
                    endY = ev.value * (SCREEN_HEIGHT - 1) / 599;
                } else {
                    startY = ev.value * (SCREEN_HEIGHT - 1) / 599;
                }
            }
        } else if (ev.type == EV_KEY && ev.code == BTN_TOUCH) {
            if (ev.value == 1) { // 触摸开始
                isTouching = 1;
            } else if (ev.value == 0 && isTouching) { // 触摸结束
                isTouching = 0;

                // 检查是否点击了数字键区域
                if (startX >= BUTTON_X_MIN && startX <= BUTTON_X_MAX &&
                    startY >= BUTTON_Y_MIN && startY <= BUTTON_Y_MAX) {
                    int buttonX = (startX - BUTTON_X_MIN) / BUTTON_WIDTH;
                    int buttonY = (startY - BUTTON_Y_MIN) / BUTTON_HEIGHT;

                    touchEvent.type = TOUCH_CLICK;
                    touchEvent.x = startX;
                    touchEvent.y = startY;
                    touchEvent.x = buttonY * 3 + buttonX + 1;
                    if (touchEvent.x > 9) touchEvent.x = -1; // 取消键
                    return touchEvent;
                }

                // 计算滑动距离
                int deltaX = endX - startX;
                int deltaY = endY - startY;

                // 判断手势
                if (abs(deltaX) > abs(deltaY)) {
                    if (deltaX > SWIPE_THRESHOLD) {
                        touchEvent.type = TOUCH_SWIPE_RIGHT;
                    } else if (deltaX < -SWIPE_THRESHOLD) {
                        touchEvent.type = TOUCH_SWIPE_LEFT;
                    }
                } else {
                    if (deltaY > SWIPE_THRESHOLD) {
                        touchEvent.type = TOUCH_SWIPE_DOWN;
                    } else if (deltaY < -SWIPE_THRESHOLD) {
                        touchEvent.type = TOUCH_SWIPE_UP;
                    }
                }
                return touchEvent;
            }
        }
    }
}

