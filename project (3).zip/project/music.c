#include "music.h"
#include "lcd.h"
#include "touch.h"
#include "songtu.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
SongImagePair songImagePairs[] = {
    {"./bg.mp3", "./zjl.bmp"},
    {"./gbqq.mp3", "./zjl.bmp"},
    {"./hktk.mp3", "./beyond.bmp"},
    {"./xqg.mp3", "./sdl.bmp"}
};
static pid_t audio_pid = -2; // 初始值设置为-2，表示没有子进程在播放音乐
int currentSongIndex = 0; // 当前歌曲索引
// 播放指定路径的音频文件
void playAudio(const char *audioFilePath) {
    if (audio_pid != -2) {
        // 如果有正在播放的音乐，先停止
        stopAudio();
    }

    audio_pid = fork();
    if (audio_pid == -1) {
        perror("fork error");
        return;
    } else if (audio_pid == 0) {
        // 子进程执行 madplay 播放音乐
        execl("/usr/bin/madplay", "madplay", audioFilePath, (char *)NULL);
        perror("execl error"); // 如果 execl 失败，输出错误信息
        exit(EXIT_FAILURE);
    } else {
        // 父进程中可以更新UI等操作
        setPlaying(true); // 设置播放状态
    }
}

// 停止当前播放的音频（如果有的话）
void stopAudio(void) {
    if (audio_pid != -2) {
        kill(audio_pid, SIGTERM); // 发送终止信号给子进程
        waitpid(audio_pid, NULL, 0); // 等待子进程退出
        audio_pid = -2;
        setPlaying(false); // 设置暂停状态
    }
}

// 播放当前歌曲
void playCurrentSong() {
    playAudio(songImagePairs[currentSongIndex].audioFilePath);
    showCurrentImage(); // 显示当前图片
}

// 停止当前歌曲
void stopCurrentSong() {
    stopAudio();
}

// 显示当前图片
void showCurrentImage() {
    lcdDrawBMP(0, 0, songImagePairs[currentSongIndex].imageFilePath);
}

// 切换到上一首歌曲和图片
void previousSong() {
    currentSongIndex = (currentSongIndex > 0) ? currentSongIndex - 1 : sizeof(songImagePairs) / sizeof(SongImagePair) - 1;
    stopCurrentSong();
    showCurrentImage();
    playCurrentSong();
}

// 切换到下一首歌曲和图片
void nextSong() {
    currentSongIndex = (currentSongIndex < sizeof(songImagePairs) / sizeof(SongImagePair) - 1) ? currentSongIndex + 1 : 0;
    stopCurrentSong();
    showCurrentImage();
    playCurrentSong();
}

// 暂停当前歌曲
void pauseSong() {
    if (audio_pid != -2) {
        kill(audio_pid, SIGSTOP); // 发送暂停信号给子进程
        setPlaying(false); // 设置暂停状态
    }
}

// 继续播放当前歌曲
void resumeSong() {
    if (audio_pid != -2) {
        kill(audio_pid, SIGCONT); // 发送继续播放信号给子进程
        setPlaying(true); // 设置播放状态
    }
}