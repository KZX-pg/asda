#ifndef __SONGTU_H__
#define __SONGTU_H__

#include "music.h"
#include "lcd.h"
#include "touch.h" // 确保 TouchEvent 已定义
#include <stdbool.h>

void initSongTu();
bool isPlaying();
void setPlaying(bool playing);
void processMusicControlEvents(TouchEvent event);

extern volatile int isLocked; // 声明为外部变量

#endif // __SONGTU_H__