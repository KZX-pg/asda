#ifndef __TOUCH_H__
#define __TOUCH_H__
#include "config.h"

typedef enum {
    TOUCH_NONE,
    TOUCH_CLICK,
    TOUCH_SWIPE_LEFT,
    TOUCH_SWIPE_RIGHT,
    TOUCH_SWIPE_UP,
    TOUCH_SWIPE_DOWN
} TouchEventType;

typedef struct {
    int type;
    int x;
    int y;
    int gestureCode; // 确保包含此成员
} TouchEvent;

// 处理解锁后的触摸事件
void handleUnlockedTouch(TouchEvent event);
/************************************************
 * 功能：初始化触摸屏
 * 参数：无
 * 返回值：
 *      -1：失败
 *       0：成功
*************************************************/
int touchInit();

/************************************************
 * 功能：关闭触摸屏
 * 参数：无
 * 返回值：无
*************************************************/
void touchClose();

/************************************************
 * 功能：获取触摸屏数据
 * 参数：无
 * 返回值：
 *      -1：获取触摸屏数据失败
 *       0：未知操作
 *       1：点击了按键1
 *       2：点击了按键2
 *       3：点击了按键3
 *      11：上划
 *      12：下划
 *      13：左划
 *      14：右划
*************************************************/
TouchEvent getTouchData();

#endif