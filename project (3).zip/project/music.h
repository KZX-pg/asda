#ifndef MUSIC_H
#define MUSIC_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    const char *audioFilePath;
    const char *imageFilePath;
} SongImagePair;



// 播放指定路径的音频文件
void playAudio(const char *audioFilePath);

// 停止当前播放的音频（如果有的话）
void stopAudio(void);
void playCurrentSong(void);
void stopCurrentSong(void);
void showCurrentImage(void);
void previousSong(void);
void nextSong(void);
void pauseSong(void);
void resumeSong(void);
#endif // MUSIC_H